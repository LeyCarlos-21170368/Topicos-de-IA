package com.example.ahorcado.model;

import java.util.Random;

public class Diccionario {

    // 1. Arreglos con las palabras categorizadas por dificultad
    private String[] palabrasFaciles = {"SOL", "LUNA", "GATO", "POLLO", "AGUA"};
    private String[] palabrasMedias = {"SISTEMA", "PYTHON", "TECLADO", "CODIGO", "TORTUGA"};
    private String[] palabrasDificiles = {"MURCIELAGO", "INGENIERIA", "TECNOLOGICO", "COMPUTADORA", "MICROCONTROLADOR"};

    private Random random;

    // Constructor
    public Diccionario() {
        random = new Random();
    }

    // 2. Método principal que será llamado desde el controlador
    // Recibe un número: 0 = Fácil, 1 = Medio, 2 = Difícil
    public String obtenerPalabraAleatoria(int nivel) {
        String[] arregloSeleccionado;

        // Seleccionamos el arreglo correspondiente usando un switch
        switch (nivel) {
            case 0:
                arregloSeleccionado = palabrasFaciles;
                break;
            case 1:
                arregloSeleccionado = palabrasMedias;
                break;
            case 2:
                arregloSeleccionado = palabrasDificiles;
                break;
            default:
                arregloSeleccionado = palabrasFaciles; // Nivel por defecto por seguridad
                break;
        }

        // 3. Generamos un índice aleatorio basado en el tamaño del arreglo elegido
        int indiceAleatorio = random.nextInt(arregloSeleccionado.length);

        // Retornamos la palabra ganadora
        return arregloSeleccionado[indiceAleatorio];
    }
}