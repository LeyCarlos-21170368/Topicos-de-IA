package com.example.ahorcado.view;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.app.AlertDialog;
import android.content.DialogInterface;

// Aquí importamos el diccionario que creaste en la otra carpeta
import com.example.ahorcado.R;
import com.example.ahorcado.model.Diccionario;

public class MainActivity extends AppCompatActivity {

    // 1. Variables de la Interfaz (Pantalla)
    private TextView tvPalabraOculta;
    private ImageView ivAhorcado;
    private GridLayout glTeclado;

    // 2. Variables de la Lógica del Juego
    private Diccionario diccionario;
    private String palabraSeleccionada;
    private char[] palabraProgreso;
    private int errores = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Enlazar las variables de Java con los IDs de tu XML
        tvPalabraOculta = findViewById(R.id.tvPalabraOculta);
        ivAhorcado = findViewById(R.id.ivAhorcado);
        glTeclado = findViewById(R.id.glTeclado);

        // Inicializar la base de datos de palabras
        diccionario = new Diccionario();

        // Arrancar la partida en Nivel Fácil (0)
        iniciarJuego(0);

        // Dibujar el teclado dinámicamente
        generarTeclado();
    }

    private void iniciarJuego(int nivel) {
        errores = 0;
        // Pedimos una palabra al azar a nuestro modelo
        palabraSeleccionada = diccionario.obtenerPalabraAleatoria(nivel);

        // Creamos un arreglo de caracteres del mismo tamaño que la palabra
        palabraProgreso = new char[palabraSeleccionada.length()];

        // Lo llenamos de guiones bajos
        for (int i = 0; i < palabraProgreso.length; i++) {
            palabraProgreso[i] = '_';
        }

        actualizarTextoPantalla();
    }

    private void actualizarTextoPantalla() {
        // Unimos los caracteres con un espacio de separación para que se vea bien
        StringBuilder mostrar = new StringBuilder();
        for (char letra : palabraProgreso) {
            mostrar.append(letra).append(" ");
        }
        tvPalabraOculta.setText(mostrar.toString());
    }

    private void generarTeclado() {
        // Definimos nuestro abecedario
        char[] alfabeto = "ABCDEFGHIJKLMNÑOPQRSTUVWXYZ".toCharArray();

        // Ciclo for para crear un botón por cada letra
        for (char letra : alfabeto) {
            Button btnLetra = new Button(this);
            btnLetra.setText(String.valueOf(letra));

            // Configuramos los márgenes del botón para que no estén pegados
            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
            params.width = GridLayout.LayoutParams.WRAP_CONTENT;
            params.height = GridLayout.LayoutParams.WRAP_CONTENT;
            params.setMargins(5, 5, 5, 5);
            btnLetra.setLayoutParams(params);

            // Le decimos al botón qué hacer cuando lo presionen
            btnLetra.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    btnLetra.setEnabled(false); // Desactiva el botón para no pulsarlo dos veces

                    // Aquí llamaremos a la lógica de validación (Por ahora solo muestra un mensaje)
                    Toast.makeText(MainActivity.this, "Letra: " + letra, Toast.LENGTH_SHORT).show();

                    // LLAMAMOS A LA LÓGICA REAL AQUÍ
                    verificarLetra(letra);
                }
            });

            // Agregamos el botón creado al contenedor GridLayout de la pantalla
            glTeclado.addView(btnLetra);
        }
    }
    // --- LÓGICA CENTRAL DEL JUEGO ---

    private void verificarLetra(char letra) {
        boolean acierto = false;

        // 1. Recorremos la palabra buscando la letra presionada
        for (int i = 0; i < palabraSeleccionada.length(); i++) {
            if (palabraSeleccionada.charAt(i) == letra) {
                palabraProgreso[i] = letra; // Reemplazamos el guion por la letra
                acierto = true;
            }
        }

        // 2. Evaluamos qué pasó
        if (acierto) {
            actualizarTextoPantalla();
            verificarVictoria();
        } else {
            errores++;
            dibujarAhorcado();
            verificarDerrota();
        }
    }

    private void verificarVictoria() {
        // Convertimos el arreglo de progreso a un String normal para compararlo
        String progresoActual = new String(palabraProgreso);

        if (progresoActual.equals(palabraSeleccionada)) {
            apagarTeclado();
            mostrarDialogoReinicio("¡VICTORIA!", "Eres un genio, adivinaste: " + palabraSeleccionada);
        }
    }

    private void verificarDerrota() {
        if (errores >= 6) {
            apagarTeclado();
            mostrarDialogoReinicio("¡DERROTA!", "Te ahorcaron. La palabra era: " + palabraSeleccionada);
        }
    }

    private void apagarTeclado() {
        // Apaga todos los botones cuando el juego termina
        for (int i = 0; i < glTeclado.getChildCount(); i++) {
            glTeclado.getChildAt(i).setEnabled(false);
        }
    }

    private void dibujarAhorcado() {

            switch (errores) {
                case 0:
                    ivAhorcado.setImageResource(R.drawable.ahorcado_0);
                    break;
                case 1:
                    ivAhorcado.setImageResource(R.drawable.ahorcado_1);
                    break;
                case 2:
                    ivAhorcado.setImageResource(R.drawable.ahorcado_2);
                    break;
                case 3:
                    ivAhorcado.setImageResource(R.drawable.ahorcado_3);
                    break;
                case 4:
                    ivAhorcado.setImageResource(R.drawable.ahorcado_4);
                    break;
                case 5:
                    ivAhorcado.setImageResource(R.drawable.ahorcado_5);
                    break;
                case 6:
                    ivAhorcado.setImageResource(R.drawable.ahorcado_6);
                    break;
            }
        }
    private void mostrarDialogoReinicio(String titulo, String mensaje) {
        new AlertDialog.Builder(this)
                .setTitle(titulo)
                .setMessage(mensaje)
                .setCancelable(false)
                .setPositiveButton("Jugar de nuevo", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        iniciarJuego(0);
                        reiniciarTeclado();
                    }
                })
                .show();
    }

    private void reiniciarTeclado() {
        // Vuelve a encender todos los botones para la nueva partida
        for (int i = 0; i < glTeclado.getChildCount(); i++) {
            glTeclado.getChildAt(i).setEnabled(true);
        }
    }
    }

