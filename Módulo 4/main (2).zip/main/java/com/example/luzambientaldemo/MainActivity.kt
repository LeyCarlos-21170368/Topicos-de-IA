package com.example.luzambientaldemo

import android.content.Context
import android.graphics.Color
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var lightSensor: Sensor? = null

    // Variables para la interfaz
    private lateinit var tvLightValue: TextView
    private lateinit var layoutPrincipal: View // Representa el fondo de la pantalla

    // Umbral para decidir cuándo es "de noche"
    private val UMBRAL_OSCURIDAD = 30.0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvLightValue = findViewById(R.id.tvLightValue)
        // Enlazamos el layout principal (asegúrate de darle el ID 'rootLayout' en tu XML)
        layoutPrincipal = findViewById(R.id.rootLayout)

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT)
    }

    override fun onResume() {
        super.onResume()
        lightSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        }
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type == Sensor.TYPE_LIGHT) {
            val valorLux = event.values[0]

            // Actualizamos el texto
            tvLightValue.text = "Iluminación: $valorLux lx"

            // Lógica de reacción visual
            if (valorLux < UMBRAL_OSCURIDAD) {
                // Entorno oscuro: Cambiamos a Modo Noche
                layoutPrincipal.setBackgroundColor(Color.parseColor("#121212")) // Gris muy oscuro
                tvLightValue.setTextColor(Color.WHITE)
            } else {
                // Entorno iluminado: Cambiamos a Modo Día
                layoutPrincipal.setBackgroundColor(Color.WHITE)
                tvLightValue.setTextColor(Color.BLACK)
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}