package com.example.reconocimientotec;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private PreviewView visorCamara;
    private TextView textoNombre, textoCarrera, textoMatricula;
    private ReconocedorFacial reconocedor;
    private DatabaseHelper dbHelper;
    private ExecutorService cameraExecutor;

    private static final int REQUEST_CODE_PERMISSIONS = 10;
    private final String[] REQUIRED_PERMISSIONS = new String[]{Manifest.permission.CAMERA};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Enlazar el diseño XML con el código Java
        visorCamara = findViewById(R.id.visorCamara);
        textoNombre = findViewById(R.id.textoNombre);
        textoCarrera = findViewById(R.id.textoCarrera);
        textoMatricula = findViewById(R.id.textoMatricula);

        // Inicializar los motores lógicos
        dbHelper = new DatabaseHelper(this);
        reconocedor = new ReconocedorFacial(this);
        cameraExecutor = Executors.newSingleThreadExecutor();

        // Verificar permisos y encender cámara
        if (allPermissionsGranted()) {
            startCamera();
        } else {
            ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, REQUEST_CODE_PERMISSIONS);
        }
    }

    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> cameraProviderFuture = ProcessCameraProvider.getInstance(this);

        cameraProviderFuture.addListener(() -> {
            try {
                ProcessCameraProvider cameraProvider = cameraProviderFuture.get();

                // Configurar la vista en pantalla
                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(visorCamara.getSurfaceProvider());

                // Configurar el analizador de imágenes en tiempo real
                ImageAnalysis imageAnalysis = new ImageAnalysis.Builder()
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .setTargetResolution(new android.util.Size(640, 480)) // Solicita una resolución menor
                        .build();

                imageAnalysis.setAnalyzer(cameraExecutor, new ImageAnalysis.Analyzer() {
                    @SuppressLint("UnsafeOptInUsageError")
                    @Override
                    public void analyze(@NonNull ImageProxy image) {
                        // 1. Extraer la foto
                        Bitmap bitmap = image.toBitmap();

                        // 2. Rotar la imagen
                        int rotacion = image.getImageInfo().getRotationDegrees();
                        Matrix matrix = new Matrix();
                        matrix.postRotate(rotacion);
                        Bitmap bitmapRotado = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);

                        // --- AQUÍ ASIGNAMOS LA VARIABLE QUE NECESITAS ---
                        Bitmap bitmapParaMostrar = bitmapRotado;

                        // 3. Mostrar en la UI para depurar (esto ahora sí encontrará la variable)
                        runOnUiThread(() -> {
                            ImageView debugView = findViewById(R.id.debugImageView);
                            debugView.setImageBitmap(bitmapParaMostrar);
                        });

                        // 4. Pasar a la IA
                        String etiquetaPredicha = reconocedor.reconocer(bitmapRotado);

                        // 5. Buscar en BD
                        buscarAlumnoEnBD(etiquetaPredicha);

                        image.close();
                    }
                });

                // Cambia a CameraSelector.DEFAULT_BACK_CAMERA si prefieres la cámara trasera
                CameraSelector cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA;

                cameraProvider.unbindAll();
                cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageAnalysis);

            } catch (ExecutionException | InterruptedException e) {
                Log.e("CameraX", "Error al iniciar la cámara", e);
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void buscarAlumnoEnBD(String etiqueta) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        // Hacemos la consulta usando el ID que escupió la IA (ej. "Alumno Diego")
        Cursor cursor = db.rawQuery("SELECT * FROM Alumnos WHERE id_etiqueta = ?", new String[]{etiqueta});

        if (cursor.moveToFirst()) {
            @SuppressLint("Range") String nombre = cursor.getString(cursor.getColumnIndex("nombre_completo"));
            @SuppressLint("Range") String carrera = cursor.getString(cursor.getColumnIndex("carrera"));
            @SuppressLint("Range") String matricula = cursor.getString(cursor.getColumnIndex("matricula"));

            // Actualizar la pantalla (debe hacerse en el hilo principal)
            runOnUiThread(() -> {
                textoNombre.setText(nombre);
                textoCarrera.setText("Carrera: " + carrera);
                textoMatricula.setText("Matrícula: " + matricula);
            });
        }
        cursor.close();
    }

    private boolean allPermissionsGranted() {
        for (String permission : REQUIRED_PERMISSIONS) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (allPermissionsGranted()) {
                startCamera();
            } else {
                Toast.makeText(this, "La app necesita la cámara para funcionar.", Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        cameraExecutor.shutdown();
    }
}