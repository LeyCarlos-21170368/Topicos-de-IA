package com.example.reconocimientotec;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "ControlEscolar.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE_ALUMNOS = "CREATE TABLE Alumnos (" +
                "id_etiqueta TEXT PRIMARY KEY, " +
                "nombre_completo TEXT, " +
                "semestre INTEGER, " +
                "carrera TEXT, " +
                "matricula TEXT)";

        db.execSQL(CREATE_TABLE_ALUMNOS);

        // Insertamos los 5 alumnos de prueba
        db.execSQL("INSERT INTO Alumnos VALUES ('Alumno Diego', 'Diego Ortega', 6, 'Ingeniería en Sistemas', '21170001')");
        db.execSQL("INSERT INTO Alumnos VALUES ('Alumno Marco', 'Marco Meza', 6, 'Ingeniería en Sistemas', '21170002')");
        db.execSQL("INSERT INTO Alumnos VALUES ('Alumno Luis', 'Luis Campos', 6, 'Ingeniería en Sistemas', '21170003')");
        db.execSQL("INSERT INTO Alumnos VALUES ('Alumno Kevin', 'Kevin Vidana', 6, 'Ingeniería en Sistemas', '21170004')");
        db.execSQL("INSERT INTO Alumnos VALUES ('Alumno Irving', 'Irving Ramirez', 6, 'Ingeniería en Sistemas', '21170005')");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS Alumnos");
        onCreate(db);
    }
}