package com.example.reconocimientotec;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.graphics.Bitmap;
import org.tensorflow.lite.DataType;
import org.tensorflow.lite.Interpreter;
import org.tensorflow.lite.support.common.ops.NormalizeOp;
import org.tensorflow.lite.support.image.ImageProcessor;
import org.tensorflow.lite.support.image.TensorImage;
import org.tensorflow.lite.support.image.ops.ResizeOp;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;

public class ReconocedorFacial {

    private Interpreter tflite;
    private String[] clases = {"Alumno Diego", "Alumno Irving", "Alumno Kevin", "Alumno Luis", "Alumno Marco"};

    // Variables para la estabilidad
    private int contadorFrames = 0;
    private String ultimaPrediccion = "Escaneando rostro...";

    public ReconocedorFacial(Context context) {
        try {
            tflite = new Interpreter(cargarModelo(context, "modelo_facial.tflite"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private MappedByteBuffer cargarModelo(Context context, String modeloPath) throws IOException {
        AssetFileDescriptor fileDescriptor = context.getAssets().openFd(modeloPath);
        FileInputStream inputStream = new FileInputStream(fileDescriptor.getFileDescriptor());
        FileChannel fileChannel = inputStream.getChannel();
        long startOffset = fileDescriptor.getStartOffset();
        long declaredLength = fileDescriptor.getDeclaredLength();
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength);
    }

    public String reconocer(Bitmap bitmapRostro) {
        // Contador para procesar solo 1 de cada 5 cuadros y evitar parpadeo
        contadorFrames++;
        if (contadorFrames % 5 != 0) {
            return ultimaPrediccion;
        }

        // 1. Especificar el formato para TensorFlow
        TensorImage image = new TensorImage(DataType.FLOAT32);
        image.load(bitmapRostro);

        // 2. Procesador: Redimensiona y normaliza datos
        ImageProcessor imageProcessor = new ImageProcessor.Builder()
                .add(new ResizeOp(160, 160, ResizeOp.ResizeMethod.BILINEAR))
                // Quitamos la escala de grises para conservar el color
                // Añadimos una normalización más específica para mejorar el contraste de colores
                .add(new NormalizeOp(127.5f, 127.5f))
                .build();

        image = imageProcessor.process(image);

        // 3. Ejecutar la IA
        float[][] resultado = new float[1][clases.length];
        tflite.run(image.getBuffer(), resultado);

        // 4. Buscar al alumno con mayor probabilidad
        int indiceMayor = 0;
        float probabilidadMayor = resultado[0][0];
        for (int i = 1; i < clases.length; i++) {
            if (resultado[0][i] > probabilidadMayor) {
                probabilidadMayor = resultado[0][i];
                indiceMayor = i;
            }
        }

        // 5. Filtro de confianza: Solo mostrar si es mayor al 85%
        if (probabilidadMayor > 0.85f) {
            ultimaPrediccion = clases[indiceMayor];
        } else {
            ultimaPrediccion = "Desconocido";
        }

        return ultimaPrediccion;
    }
}